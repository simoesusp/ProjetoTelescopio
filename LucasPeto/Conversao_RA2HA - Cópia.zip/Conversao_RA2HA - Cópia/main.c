// Programa de um jogo para Teste da Lib NCurses

//Extrutura do codigo:




// Variaveis para controlar cor na Curses:
//        COLOR_BLACK   0
//        COLOR_RED     1
//        COLOR_GREEN   2
//        COLOR_YELLOW  3
//        COLOR_BLUE    4
//        COLOR_MAGENTA 5
//        COLOR_CYAN    6
//        COLOR_WHITE   7

// Variaveis para controlar Cursor na Curses:
//    A_NORMAL        Normal display (no highlight)
//    A_STANDOUT      Best highlighting mode of the terminal.
//    A_UNDERLINE     Underlining
//    A_REVERSE       Reverse video
//    A_BLINK         Blinking
//    A_DIM           Half bright
//    A_BOLD          Extra bright or bold
//    A_PROTECT       Protected mode
//    A_INVIS         Invisible or blank mode
//    A_ALTCHARSET    Alternate character set
//    A_CHARTEXT      Bit-mask to extract a character
//    COLOR_PAIR(n)   Color-pair number n

/*  // Comandos especiais da Curses:
    start_color();          // Start color
	init_pair(1, COLOR_RED, COLOR_BLACK);   //Define define the foreground and background for the pair number you give
	attron(COLOR_PAIR(1));  // Activate the defined collor pair
    attron(A_BOLD);    //  Bolda tudo!
    //attroff(A_BOLD);  // Disbolda tudo
    //attrset(A_NORMAL) // turns off all attributes and brings you to normal mode.
    mvprintw(y,x, "*");  // Printa nas coordenadas x,y um *
    timeout(50);  // Delay para esperar pelo GETCH() = 5 seg
    getch();      // Wait for user input

*/



//#include <curses.h> // Novo Terminal cheio de funcoes!!!

int main()
{

//    double UT = currentTime.time().hour() + (currentTime.time().minute() / 60.0) + (currentTime.time().second() / 3600.0) + (currentTime.time().msec() / 3600000.0);

    double hour = 14;
    double minute = 36;
    double second = 51;

    double UT = hour + (minute / 60.0) + (second / 3600.0);
    printf("UT: %f\n" , UT);

    double JD = 2444351.5;

    double RAH = 18;
    double RAM = 32;
    double RAS = 21;
    double RA  = (RAH+RAM/60.0+RAS/3600.0);

/*    double LATH = 22;
    double LATM = 1;
    double LAT = -1*(LATH+LATM/60.0); // -1 sul

    double LONGH = 47;
    double LONGM = 53;
    double LONG = -1*(LONGH+LONGM/60.0);// -1 west
*/
    double LONGH = 64;
    double LONGM = 0;
    double LONGDegrees = -1*(LONGH+LONGM/60.0);// -1 west

    printf("LongDegrees: %f\n" , LONGDegrees);

    double decimalHours = UT;
    double daysFromJ2000 = JD - 2451545.0;
    //double LST = 100.46 + (0.985647 * daysFromJ2000) + LONG + (15 * decimalHours);
    double LSTDegrees = 100.46 + (0.985647 * daysFromJ2000) + LONGDegrees + (15 * decimalHours);

    while (LSTDegrees < 0) {
        LSTDegrees += 360.0;
    }
    while (LSTDegrees > 360) {
        LSTDegrees -= 360.0;
    }

    printf("LSTDegrees: %f\n", LSTDegrees);

    double RADegrees = RA * 15.0;
    printf("RA: %f      RADegrees: %f\n", RA, RADegrees);

    double HADegrees = LSTDegrees - RADegrees;
    while (HADegrees < 0) {
        HADegrees += 360.0;
    }
    while (HADegrees > 360) {
        HADegrees -= 360.0;
    }

    printf("HADegrees: %f\n", HADegrees);
    double HA = HADegrees / 15.0;

    int HAh, HAm, HAs;
    HAh = (int) HA;
    HAm = (int) ((HA - HAh)*60);
    HAs = (int) ((((HA - HAh)*60) - HAm)*60);

    printf("HAh = %d   HAm = %d    HAs = %d\n\n\n", HAh, HAm, HAs);



    double GMST_hours = 6.656306 + 0.0657098242*(JD-2445700.5) + 1.0027379093*UT;
    printf("GMST_hours: %f           ", GMST_hours);

    double LST_hours = GMST_hours + (LONGDegrees/15.0);
    while (GMST_hours < 0) {
        GMST_hours += 24.0;
    }
    while (GMST_hours > 24) {
        GMST_hours -= 24.0;
    }
    printf("GMST_hours: %f\n", GMST_hours);

    while (LST_hours < 0) {
        LST_hours += 24.0;
    }
    while (LST_hours > 24) {
        LST_hours -= 24.0;
    }
    printf("LST_hours: %f\n", LST_hours);


    HA = LST_hours - RA;
    while (HA < 0) {
        HA += 24.0;
    }
    while (HA > 24) {
        HA -= 24.0;
    }

    printf("HA: %f\n", HA);


    HAh = (int) HA;
    HAm = (int) ((HA - HAh)*60);
    HAs = (int) ((((HA - HAh)*60) - HAm)*60);


    printf("HAh = %d   HAm = %d    HAs = %d\n", HAh, HAm, HAs);













/*
	initscr();      // Start curses mode 		  //
	//noecho();   // Nao echoa as teclas digitadas no getch()
    clear();    // LIMPA A TELA
	raw();      // Desliga um buffer que nao faz diferenca!!!
	keypad(stdscr, TRUE);   // Liga Teclado numerico e setas e F1..F12
	resize_term(50,50);    // Tamanho Maximo na tela de 1200x800 = 64,159
	curs_set(0);    // Cursor disapeer!!!
                    //      0 : invisible
                    //      1 : normal
                    //      2 : very visible.

*/

fim:
//    resetty();   // Reseta o tamanho da janela!
//	endwin();       // End curses mode		  //

	return 0;
}



